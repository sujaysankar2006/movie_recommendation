# recommended.py
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import ast

class MovieRecommender:
    def __init__(self, csv_path):
        self.movies = pd.read_csv(csv_path)
        self._prepare_data()

    def _prepare_data(self):
        # Strip column names
        self.movies.columns = self.movies.columns.str.strip()

        # Check required columns
        for col in ['title', 'cast', 'crew']:
            if col not in self.movies.columns:
                raise KeyError(f"Required column '{col}' not found.")

        # Parse cast and crew JSON strings
        self.movies['cast'] = self.movies['cast'].apply(
            lambda x: ' '.join([i['name'] for i in ast.literal_eval(x)[:5]])
            if pd.notna(x) else ''
        )

        self.movies['crew'] = self.movies['crew'].apply(
            lambda x: ' '.join([i['name'] for i in ast.literal_eval(x) if i['job'] in ['Director', 'Writer']])
            if pd.notna(x) else ''
        )

        self.movies['combined'] = self.movies['cast'] + ' ' + self.movies['crew']

        # Vectorize
        self.tfidf = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = self.tfidf.fit_transform(self.movies['combined'])

    def recommend(self, user_input, top_n=5):
        user_vec = self.tfidf.transform([user_input])
        similarity = cosine_similarity(user_vec, self.tfidf_matrix)
        top_indices = similarity[0].argsort()[-top_n:][::-1]
        return self.movies.iloc[top_indices][['title', 'combined']]
