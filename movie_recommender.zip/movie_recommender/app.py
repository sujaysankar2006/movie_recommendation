# app.py
from recommender import MovieRecommender

def main():
    print("🎬 Welcome to the AI Movie Recommender!")
    user_input = input("Tell me what kind of actors, directors, or creators you like (e.g. Tom Cruise, Christopher Nolan): ")

    try:
        recommender = MovieRecommender("tmdb_5000_movies.csv")  # Make sure this is the correct file
        recommendations = recommender.recommend(user_input)

        print("\n✨ Recommended Movies:\n")
        for i, row in recommendations.iterrows():
            print(f"🎥 {row['title']}")
            print(f"   🎭 Based on: {row['combined'][:150]}...\n")

    except Exception as e:
        print(f"⚠️ Error: {e}")

if __name__ == "__main__":
    main()
